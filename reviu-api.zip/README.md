RecordRTC / PHP / FFmpeg
https://github.com/muaz-khan/WebRTC-Experiment/tree/master/RecordRTC/PHP-and-FFmpeg

This demo can:

record both audio/video
merge in single WebM using ffmpeg
audio is synced with video using ffmpeg commands!
it supports longest possible recordings!