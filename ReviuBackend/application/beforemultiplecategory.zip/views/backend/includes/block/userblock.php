<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/edituser?id=').$before->id; ?>">User Details</a></li>
<li><a href="<?php echo site_url('site/editaddress?id=').$before->id; ?>">Address</a></li>
<li><a href="<?php echo site_url('site/viewuserinterestevents?id=').$before->id; ?>">User Interest Events</a></li>
</ul>
</div>
</section>